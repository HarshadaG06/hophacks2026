# %% Load and preprocess data

from datasets import load_dataset
import pandas as pd
import matplotlib.pyplot as plt

print("Loading dataset...")
# Load just the train split to avoid dealing with a DatasetDict wrapper
ds = load_dataset("The-data-company/TikTok-10M", split="train")

print("Extracting columns to Pandas...")

## 
cols_to_keep = [
    "id", "create_time", "desc", "play_count", 
    "music_id", "music_title", "music_duration", 
    "music_original", "url", "user_id", "user_verified",
    "challenges"
]

# EFFICIENCY TRICK: Drop everything except the columns we need BEFORE converting to Pandas
ds_slim = ds.select_columns(cols_to_keep)
df = ds_slim.to_pandas()

# Clean up missing data
df = df.dropna(subset=cols_to_keep)

print("Calculating top 500 audios...")
# Find the 500 most frequently used music_ids
top_500_audios = df['music_id'].value_counts().nlargest(500).index

# Filter our massive dataframe down to just videos using these 500 audios
df_top = df[df['music_id'].isin(top_500_audios)].copy()

# %%
df.to_parquet("10M_processed.parquet", index=False)
df_top.to_parquet("top_500_audios.parquet", index=False)
print("Saved preprocessed data to 10M_processed.parquet and top_500_audios.parquet")

# %% Plot 
print("Processing timelines...")
# Convert Unix timestamp to readable dates
df_top['create_date'] = pd.to_datetime(df_top['create_time'], unit='s')

# Round down to the nearest week. 
# Plotting by exact second/day makes the lines too jagged and chaotic.
df_top['week'] = df_top['create_date'].dt.to_period('W').dt.start_time

print("Structuring chart data...")
# Pivot so Rows = Weeks, Columns = music_id, Values = Video count
pivot_df = df_top.groupby(['week', 'music_id']).size().unstack(fill_value=0)

print("Plotting...")
plt.figure(figsize=(14, 7))

# Plot all 500 lines. 
# alpha=0.15 makes individual lines faint, but overlapping trends will glow dark teal.
pivot_df.plot(ax=plt.gca(), legend=False, alpha=0.15, color='teal', linewidth=1.5)

plt.title('Trending Lifespans: Top 500 TikTok Audios Over Time', fontsize=14, pad=15)
plt.xlabel('Creation Date', fontsize=12)
plt.ylabel('Videos Posted per Week', fontsize=12)

# Clean up the visual aesthetics
plt.grid(True, axis='y', alpha=0.3)
plt.gca().spines['top'].set_visible(False)
plt.gca().spines['right'].set_visible(False)

plt.tight_layout()
plt.show()

# %% Plot by relative life span (first 3 months per audio)
print("Calculating relative lifespans (Ultra-fast integer math)...")

# 1. Find birth time using the raw integer seconds (create_time), NOT the date object
birth_times = df_top.groupby('music_id')['create_time'].min().reset_index()
birth_times.rename(columns={'create_time': 'birth_time'}, inplace=True)

# 2. Merge the birth times back in
df_top = df_top.merge(birth_times, on='music_id')

# 3. Calculate week index using pure math (There are 604,800 seconds in a week)
# This subtracts the seconds, then divides by seconds-per-week, skipping datetime entirely!
df_top['week_index'] = (df_top['create_time'] - df_top['birth_time']) // 604800

# 4. Filter to keep only the first 5 months (~20 weeks)
df_first_n_weeks = df_top[df_top['week_index'] <= 20]

print("Pivoting data for charting...")
# Group by week_index and music_id to count total videos per week
pivot_df = df_first_n_weeks.groupby(['week_index', 'music_id']).size().unstack(fill_value=0)

print("Plotting...")
plt.figure(figsize=(12, 6))

# Plot all 500 lines. Low opacity makes overlapping viral patterns stand out.
pivot_df.plot(ax=plt.gca(), legend=False, alpha=0.15, color='teal', linewidth=1.5)

plt.title('Viral Trajectory: First 5 Months of the Top 500 Audios', fontsize=14, pad=15)
plt.xlabel('Weeks Since Audio First Appeared', fontsize=12)
plt.ylabel('New Videos Posted per Week', fontsize=12)

# Lock x-axis to exactly 0-20 weeks
plt.xlim(0, 20)
plt.xticks(range(0, 21))

# Clean up visual aesthetics
plt.grid(True, axis='both', alpha=0.3)
plt.gca().spines['top'].set_visible(False)
plt.gca().spines['right'].set_visible(False)

plt.tight_layout()
plt.show()

# %% Plot Share of Voice (Normalized by total platform uploads per week)
print("Calculating Share of Voice directly from in-memory data...")

SECONDS_PER_WEEK = 604800

# 1. Total weekly platform uploads across the entire dataset
df['calendar_week'] = df['create_time'] // SECONDS_PER_WEEK
platform_weekly_totals = df['calendar_week'].value_counts()

# 2. Slice to the first 20 weeks using df_top (already has week_index from the previous cell)
df_sov = df_top[df_top['week_index'] <= 20].copy()
df_sov['calendar_week'] = df_sov['create_time'] // SECONDS_PER_WEEK
df_sov['platform_total'] = df_sov['calendar_week'].map(platform_weekly_totals)

# 3. Individual video weight as % of its calendar week's total uploads
df_sov['sov_weight'] = (1.0 / df_sov['platform_total']) * 100

# 4. Sum weights into a relative-week matrix
sov_pivot = (
    df_sov.groupby(['week_index', 'music_id'])['sov_weight']
    .sum()
    .unstack(fill_value=0)
)

print("Plotting Share of Voice...")
plt.figure(figsize=(13, 7))

# Plot all 500 individual trajectories
sov_pivot.plot(ax=plt.gca(), legend=False, alpha=0.15, color='teal', linewidth=1.2)

# Plot median trajectory across all 500 tracks
median_sov = sov_pivot.median(axis=1)
plt.plot(
    median_sov.index, 
    median_sov.values, 
    color='crimson', 
    linewidth=2.5, 
    label='Median Lifecycle Trend'
)

plt.title('Top 500 TikTok Audios: Share of Voice Over First 5 Months', fontsize=14, pad=15)
plt.xlabel('Weeks Since Audio First Appeared (Relative Age)', fontsize=12)
plt.ylabel('% of Total Platform Uploads (Share of Voice)', fontsize=12)

plt.xlim(0, 20)
plt.xticks(range(0, 21))

plt.grid(True, axis='both', alpha=0.3)
plt.gca().spines['top'].set_visible(False)
plt.gca().spines['right'].set_visible(False)
plt.legend(loc='upper right', frameon=True)

plt.tight_layout()
plt.show()
# %%
