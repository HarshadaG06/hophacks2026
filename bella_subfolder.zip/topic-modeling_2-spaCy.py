# %% Config
# One-time setup:
#   pip install spacy wordninja scipy tqdm
#   python -m spacy download en_core_web_lg     # needs a model WITH word vectors (not *_sm)
import numpy as np
import pandas as pd
import spacy
from scipy import sparse
from tqdm.auto import tqdm

# --- Files ---
CLEAN_PARQUET = "top_500_text_clean.parquet"   # output of the cleaning script
CAPTION_EMB_NPY = "caption_embeddings.npy"     # rows align with CLEAN_PARQUET
HASHTAG_EMB_NPY = "hashtag_embeddings.npy"     # rows align with CLEAN_PARQUET

# --- Columns (from the cleaning script) ---
CAPTION_COL = "caption_clean"
CAPTION_EMPTY_COL = "caption_empty"
TAGS_COL = "tags_clean"

# --- spaCy ---
SPACY_MODEL = "en_core_web_lg"   # md works too (smaller vocab -> more zero vectors)
# Components not needed for vectors; excluding them makes the pipeline ~tokenizer-only
SPACY_EXCLUDE = ["tok2vec", "tagger", "parser", "attribute_ruler", "lemmatizer", "ner", "senter"]
BATCH_SIZE = 2000
N_PROCESS = 1                    # keep at 1 in notebooks / VS Code cells (multiprocessing can hang)
EMB_DTYPE = np.float32

# --- Hashtags ---
SEGMENT_HASHTAGS = True          # "dancechallenge" -> "dance challenge" (needs `wordninja`)


# %% Helpers
def load_nlp():
    nlp = spacy.load(SPACY_MODEL, exclude=SPACY_EXCLUDE)
    if nlp.vocab.vectors_length == 0:
        raise ValueError(
            f"{SPACY_MODEL} has no word vectors. Use a *_md or *_lg model "
            f"(python -m spacy download en_core_web_lg)."
        )
    return nlp


def embed_texts(nlp, texts):
    """Mean word vector per text (stopwords, punctuation, and OOV tokens skipped).

    Texts with no usable tokens get an all-zero vector.
    """
    out = np.zeros((len(texts), nlp.vocab.vectors_length), dtype=EMB_DTYPE)
    docs = nlp.pipe(texts, batch_size=BATCH_SIZE, n_process=N_PROCESS)
    for i, doc in enumerate(tqdm(docs, total=len(texts))):
        vecs = [
            t.vector for t in doc
            if t.has_vector and not (t.is_stop or t.is_punct or t.is_space)
        ]
        if vecs:
            out[i] = np.mean(vecs, axis=0)
    return out


def make_segmenter():
    """Return a function that splits glued hashtags into words (identity if unavailable)."""
    if not SEGMENT_HASHTAGS:
        return lambda tag: tag
    try:
        import wordninja
    except ImportError:
        print("wordninja not installed -> hashtags will NOT be segmented "
              "(pip install wordninja). Expect many more zero vectors.")
        return lambda tag: tag

    def segment(tag):
        if not tag.isascii():          # wordninja only handles ASCII; keep other scripts as-is
            return tag
        words = wordninja.split(tag)
        # Unknown strings get shattered into stray letters ("qq q zzz"); keep those whole
        # (-> zero vector) instead of embedding noise. Only "a" and "i" are valid 1-letter words.
        if not words or any(len(w) == 1 and w not in ("a", "i") for w in words):
            return tag
        return " ".join(words)

    return segment


def coverage(emb):
    """Share of rows with a non-zero vector."""
    return (np.linalg.norm(emb, axis=1) > 0).mean()


# %% Load
nlp = load_nlp()
print(f"Loaded {SPACY_MODEL} ({nlp.vocab.vectors_length}-d vectors)")

df = pd.read_parquet(CLEAN_PARQUET, columns=[CAPTION_COL, CAPTION_EMPTY_COL, TAGS_COL])
df = df.reset_index(drop=True)
print(f"{len(df):,} videos")


# %% Caption embeddings
# Embed each UNIQUE caption once, then broadcast back to rows (captions repeat a lot).
captions = df[CAPTION_COL].where(~df[CAPTION_EMPTY_COL], "").str.lower()
codes, uniques = pd.factorize(captions)
print(f"Embedding {len(uniques):,} unique captions (of {len(df):,} videos)...")

caption_emb = embed_texts(nlp, uniques.tolist())[codes]
print(f"Caption vector coverage: {coverage(caption_emb):.1%}")


# %% Hashtag embeddings
# Embed each UNIQUE tag once, then average the tag vectors within each video.
exploded = df[TAGS_COL].explode().dropna()               # index = video row position
tag_counts = exploded.value_counts()
tags = tag_counts.index
print(f"Embedding {len(tags):,} unique hashtags...")

segment = make_segmenter()
tag_emb = embed_texts(nlp, [segment(t) for t in tags])
tag_has_vec = np.linalg.norm(tag_emb, axis=1) > 0

# Sparse (video x tag) matrix -> mean of each video's tag vectors, ignoring zero-vector tags
rows = exploded.index.to_numpy()
cols = tags.get_indexer(exploded)
keep = tag_has_vec[cols]
membership = sparse.csr_matrix(
    (np.ones(keep.sum(), dtype=EMB_DTYPE), (rows[keep], cols[keep])),
    shape=(len(df), len(tags)),
)
n_tags_per_video = np.asarray(membership.sum(axis=1)).ravel()
hashtag_emb = (membership @ tag_emb).astype(EMB_DTYPE)
nonzero = n_tags_per_video > 0
hashtag_emb[nonzero] /= n_tags_per_video[nonzero, None]

print(f"Unique tags with a vector:  {tag_has_vec.mean():.1%}")
print(f"Hashtag vector coverage (videos): {coverage(hashtag_emb):.1%}")
print("\nMost frequent hashtags with NO vector (candidates to inspect):")
print(tag_counts[~tag_has_vec].head(20).to_string())


# %% Save
np.save(CAPTION_EMB_NPY, caption_emb)
np.save(HASHTAG_EMB_NPY, hashtag_emb)
print(f"\nSaved {CAPTION_EMB_NPY} {caption_emb.shape} and {HASHTAG_EMB_NPY} {hashtag_emb.shape}")
print("Rows with no usable text have all-zero vectors -- mask them out before UMAP/clustering.")