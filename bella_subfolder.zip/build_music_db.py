#!/usr/bin/env python3
"""
build_music_db.py - preprocess a TikTok-videos Parquet file into a DuckDB database
with two tables: music_summary and music_hourly.

Usage
-----
    pip install duckdb
    python build_music_db.py videos-00.parquet --min-videos 50
    python build_music_db.py "data/videos-*.parquet" --db tiktok_music.duckdb --partitions 32
    python build_music_db.py videos-00.parquet --temp-dir /Volumes/External/duck_tmp

Tables
------
music_summary   (one row per music_id)
    music_id        UBIGINT
    first_seen      TIMESTAMP   earliest create_time (UTC)
    last_seen       TIMESTAMP   latest create_time (UTC)
    num_videos      BIGINT      posts using this music_id
    total_views     BIGINT      sum of views over those posts
    max_views       BIGINT      views of the single most-viewed post
    num_countries   BIGINT      distinct non-empty country values
    num_languages   BIGINT      distinct non-empty language values (see --ignore-language-codes)

music_hourly    (one row per music_id x hour that has at least one post)
    music_id        UBIGINT
    hour            TIMESTAMP   create_time truncated to the hour (UTC)
    num_videos      BIGINT      posts created in that hour using this music_id
    content_ids     VARCHAR     'id1;id2;id3' - every content_id from that hour, ascending

Filters applied to the raw rows
-------------------------------
Rows with NULL/0 music_id or NULL content_id are dropped. Ads (is_ad) are dropped unless
--keep-ads. Use --videos-only to also drop photo posts.

How it stays inside your memory / disk budget
---------------------------------------------
The music_id range is split into --partitions slices of roughly equal row counts. Each slice
is loaded, aggregated into BOTH tables, and appended, so peak memory and temp-disk use are
about 1/N of a single big GROUP BY. Slices are processed in ascending music_id order, so both
tables end up globally sorted by music_id (fast lookups by music_id). If you still run out of
memory or spill space: raise --partitions, use --min-videos, or point --temp-dir at a drive
with more free space.

Example queries
---------------
    -- lifecycle curve of one sound, by day
    SELECT date_trunc('day', "hour") AS day, sum(num_videos) AS n
    FROM music_hourly WHERE music_id = 7510763963986139386 GROUP BY 1 ORDER BY 1;

    -- explode the semicolon list back into rows
    SELECT music_id, "hour", unnest(string_split(content_ids, ';'))::UBIGINT AS content_id
    FROM music_hourly WHERE music_id = 7510763963986139386;

Size warning
------------
Without --min-videos every music_id gets a row, and most original sounds are used exactly
once, so a full file yields tens of millions of rows in both tables (many GB on disk).
--min-videos keeps only sounds with enough posts to have a lifecycle.

If create_time is stored as epoch MILLISECONDS, change ts_expr below to divide by 1000.
"""
import argparse
import os
import shutil
import sys
import tempfile
import time

import duckdb

INT_TYPES = {
    "TINYINT", "SMALLINT", "INTEGER", "BIGINT", "HUGEINT",
    "UTINYINT", "USMALLINT", "UINTEGER", "UBIGINT", "UHUGEINT",
}
REQUIRED = ("music_id", "content_id", "create_time", "views", "country", "language")


def lit(s):
    """SQL string literal."""
    return "'" + str(s).replace("'", "''") + "'"


def distinct_count(col, ignore_codes):
    """count of distinct non-empty values of col, optionally ignoring some codes (e.g. 'un')."""
    cond = f"{col} IS NOT NULL AND trim({col}) <> ''"
    if ignore_codes:
        cond += f" AND lower(trim({col})) NOT IN ({', '.join(lit(c) for c in ignore_codes)})"
    return f"count(DISTINCT {col}) FILTER (WHERE {cond})"


def parse_codes(s):
    return [c.strip().lower() for c in s.split(",") if c.strip()]


def free_gb(path):
    p = os.path.abspath(path)
    while not os.path.exists(p):
        p = os.path.dirname(p)
    return shutil.disk_usage(p).free / 1e9


def parse_args():
    p = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    p.add_argument("src", help="Parquet file, glob pattern, or hf:// path")
    p.add_argument("--db", default="tiktok_music.duckdb", help="output DuckDB file")
    p.add_argument("--min-videos", type=int, default=1,
                   help="only keep sounds with at least this many posts (default 1 = keep all)")
    p.add_argument("--partitions", type=int, default=16,
                   help="number of music_id slices processed one at a time (default 16; "
                        "raise if you run out of memory)")
    p.add_argument("--keep-ads", action="store_true", help="do not drop is_ad rows")
    p.add_argument("--videos-only", action="store_true", help="drop photo posts (is_video = false)")
    p.add_argument("--ignore-language-codes", default="un",
                   help="comma-separated language codes not counted in num_languages "
                        "(default 'un' = unknown; pass '' to count everything)")
    p.add_argument("--ignore-country-codes", default="",
                   help="comma-separated country codes not counted in num_countries")
    p.add_argument("--memory-limit", default="6GB")
    p.add_argument("--threads", type=int, default=min(8, os.cpu_count() or 4))
    p.add_argument("--temp-dir", default=os.path.join(tempfile.gettempdir(), "duckdb_spill"),
                   help="where DuckDB spills to disk when memory runs out")
    p.add_argument("--max-temp-size", default=None,
                   help="cap on spill space, e.g. 50GB (default: DuckDB uses all free disk)")
    return p.parse_args()


def main():
    a = parse_args()
    os.makedirs(a.temp_dir, exist_ok=True)
    t0 = time.time()

    def log(msg):
        print(f"[{time.time() - t0:7.1f}s] {msg}", flush=True)

    db_dir = os.path.dirname(os.path.abspath(a.db))
    log(f"free disk: {free_gb(db_dir):,.1f} GB for the database, {free_gb(a.temp_dir):,.1f} GB for temp files")
    if free_gb(a.temp_dir) < 15 and a.min_videos <= 1:
        log("WARNING: little free disk and no --min-videos filter; a full build can need many GB. "
            "Consider --min-videos 50 or --temp-dir on a bigger drive.")

    if os.path.exists(a.db):
        log(f"note: {a.db} already exists; its music_summary/music_hourly tables will be replaced")
    con = duckdb.connect(a.db)
    if a.src.lower().startswith(("hf://", "http://", "https://", "s3://")):
        con.execute("INSTALL httpfs")
        con.execute("LOAD httpfs")
        log("remote source: the file is scanned several times. Consider downloading it first.")
    con.execute("SET TimeZone='UTC'")
    con.execute(f"SET memory_limit={lit(a.memory_limit)}")
    con.execute(f"SET temp_directory={lit(a.temp_dir)}")
    if a.max_temp_size:
        con.execute(f"SET max_temp_directory_size={lit(a.max_temp_size)}")
    con.execute(f"SET threads={int(a.threads)}")
    con.execute("SET preserve_insertion_order=false")

    src = f"read_parquet({lit(a.src)})"
    schema = {row[0]: row[1].upper()
              for row in con.execute(f"DESCRIBE SELECT * FROM {src}").fetchall()}
    missing = [c for c in REQUIRED if c not in schema]
    if missing:
        sys.exit(f"Missing required column(s): {missing}.\nColumns present: {sorted(schema)}\n"
                 f"Rename them in the 'base' view below if your file uses different names.")
    log(f"columns found: {sorted(schema)}")

    if schema["create_time"].split("(")[0] in INT_TYPES:
        ts_expr = "to_timestamp(CAST(create_time AS DOUBLE))"  # epoch seconds
    else:
        ts_expr = "CAST(create_time AS TIMESTAMP)"

    # ---- normalised, filtered view over the raw file ----------------------------------------
    where = ["TRY_CAST(music_id AS UBIGINT) > 0", "TRY_CAST(content_id AS UBIGINT) IS NOT NULL"]
    if "is_ad" in schema and not a.keep_ads:
        where.append("NOT COALESCE(TRY_CAST(is_ad AS BOOLEAN), FALSE)")
    if a.videos_only and "is_video" in schema:
        where.append("COALESCE(TRY_CAST(is_video AS BOOLEAN), TRUE)")
    con.execute(f"""
        CREATE OR REPLACE TEMP VIEW base AS
        SELECT TRY_CAST(music_id AS UBIGINT)   AS music_id,
               TRY_CAST(content_id AS UBIGINT) AS content_id,
               {ts_expr}                       AS ts,
               TRY_CAST(views AS BIGINT)       AS views,
               CAST(country AS VARCHAR)        AS country,
               CAST(language AS VARCHAR)       AS language
        FROM {src}
        WHERE {' AND '.join(where)}
    """)

    # ---- music_id slices (equal-ish row counts, ascending, disjoint, complete) ----------------
    n_parts = max(1, int(a.partitions))
    bounds = []
    if n_parts > 1:
        log(f"computing {n_parts} music_id slice boundaries (reads only music_id)")
        qs = [i / n_parts for i in range(1, n_parts)]
        res = con.execute(f"SELECT approx_quantile(CAST(music_id AS DOUBLE), {qs}) FROM base").fetchone()[0]
        bounds = sorted({int(x) for x in res})
    edges = [0] + bounds + [None]
    preds = []
    for lo, hi in zip(edges[:-1], edges[1:]):
        preds.append(f"music_id >= {lo}" + (f" AND music_id < {hi}" if hi is not None else ""))

    # ---- optional volume filter ---------------------------------------------------------------
    join = ""
    if a.min_videos > 1:
        log(f"finding sounds with >= {a.min_videos} posts, slice by slice")
        con.execute("CREATE OR REPLACE TEMP TABLE kept (music_id UBIGINT)")
        for pred in preds:
            con.execute(
                f"INSERT INTO kept SELECT music_id FROM base WHERE {pred} "
                f"GROUP BY music_id HAVING count(*) >= {int(a.min_videos)}"
            )
        n_kept = con.execute("SELECT count(*) FROM kept").fetchone()[0]
        log(f"{n_kept:,} sounds kept")
        if n_kept == 0:
            sys.exit("No sounds pass --min-videos; lower it.")
        join = "JOIN kept USING (music_id)"

    # ---- create empty target tables -----------------------------------------------------------
    con.execute("""
        CREATE OR REPLACE TABLE music_summary (
            music_id UBIGINT, first_seen TIMESTAMP, last_seen TIMESTAMP, num_videos BIGINT,
            total_views BIGINT, max_views BIGINT, num_countries BIGINT, num_languages BIGINT)""")
    con.execute("""
        CREATE OR REPLACE TABLE music_hourly (
            music_id UBIGINT, "hour" TIMESTAMP, num_videos BIGINT, content_ids VARCHAR)""")

    country_expr = distinct_count("country", parse_codes(a.ignore_country_codes))
    language_expr = distinct_count("language", parse_codes(a.ignore_language_codes))

    # ---- main loop: one slice at a time, feeding both tables ----------------------------------
    for k, pred in enumerate(preds, 1):
        con.execute("DROP TABLE IF EXISTS part")
        con.execute(f"CREATE TEMP TABLE part AS SELECT * FROM base {join} WHERE {pred}")
        n_rows = con.execute("SELECT count(*) FROM part").fetchone()[0]
        con.execute(f"""
            INSERT INTO music_summary
            SELECT music_id, min(ts), max(ts), count(*), sum(views)::BIGINT, max(views),
                   {country_expr}, {language_expr}
            FROM part GROUP BY music_id ORDER BY music_id""")
        con.execute("""
            INSERT INTO music_hourly
            SELECT music_id, date_trunc('hour', ts), count(*),
                   string_agg(CAST(content_id AS VARCHAR), ';' ORDER BY content_id)
            FROM part GROUP BY music_id, date_trunc('hour', ts)
            ORDER BY music_id, date_trunc('hour', ts)""")
        con.execute("DROP TABLE part")
        con.execute("CHECKPOINT")
        log(f"slice {k}/{len(preds)} done ({n_rows:,} posts)")

    n_sum = con.execute("SELECT count(*) FROM music_summary").fetchone()[0]
    n_hr = con.execute("SELECT count(*) FROM music_hourly").fetchone()[0]
    log(f"music_summary: {n_sum:,} rows; music_hourly: {n_hr:,} rows")

    # ---- consistency checks (kept cheap: scalar aggregates + small samples) --------------------
    tot_s = con.execute("SELECT sum(num_videos) FROM music_summary").fetchone()[0]
    tot_h = con.execute("SELECT sum(num_videos) FROM music_hourly").fetchone()[0]
    con.execute("CREATE OR REPLACE TEMP TABLE samp AS "
                "SELECT music_id, num_videos FROM music_summary USING SAMPLE 2000 ROWS")
    per_sound_bad = con.execute("""
        SELECT count(*) FROM samp s JOIN (
            SELECT music_id, sum(num_videos) AS n FROM music_hourly
            WHERE music_id IN (SELECT music_id FROM samp) GROUP BY 1) t USING (music_id)
        WHERE s.num_videos <> t.n""").fetchone()[0]
    list_bad = con.execute("""
        SELECT count(*) FROM (
          SELECT num_videos, len(string_split(content_ids, ';')) AS n
          FROM music_hourly USING SAMPLE 10000 ROWS) WHERE n <> num_videos""").fetchone()[0]
    print("\n=== checks ===")
    print(f"  videos in music_summary : {tot_s:,}")
    print(f"  videos in music_hourly  : {tot_h:,}   ({'OK' if tot_s == tot_h else 'MISMATCH'})")
    print(f"  sampled sounds with count mismatch between tables: {per_sound_bad}")
    print(f"  sampled hourly rows where list length != num_videos: {list_bad}")
    lo, hi = con.execute("SELECT min(first_seen), max(last_seen) FROM music_summary").fetchone()
    print(f"  time range: {lo} -> {hi}")

    print("\n=== top 5 sounds by num_videos ===")
    for row in con.execute("SELECT * FROM music_summary ORDER BY num_videos DESC LIMIT 5").fetchall():
        print("  ", row)
    print("\n=== sample music_hourly row ===")
    r = con.execute("""SELECT music_id, "hour", num_videos, substr(content_ids, 1, 60) || '...'
                       FROM music_hourly ORDER BY num_videos DESC LIMIT 1""").fetchone()
    print("  ", r)
    con.close()
    size_mb = os.path.getsize(a.db) / 1e6
    log(f"done -> {a.db} ({size_mb:,.1f} MB)")


if __name__ == "__main__":
    main()
