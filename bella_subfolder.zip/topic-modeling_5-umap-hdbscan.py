# %% Config
# pip install umap-learn hdbscan scikit-learn scipy matplotlib
import hdbscan
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import umap
from scipy import sparse
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import normalize

# --- Files ---
CLEAN_PARQUET = "top_500_text_clean.parquet"
CAPTION_EMB_NPY = "caption_embeddings.npy"
HASHTAG_EMB_NPY = "hashtag_embeddings.npy"
ASSIGNMENTS_PARQUET = "topic_assignments.parquet"   # one row per video, same order as CLEAN_PARQUET
# per modality (name = "caption" / "hashtag"): topics_<name>.csv and topics_<name>_umap.png

# --- Columns ---
ID_COL = "id"
AUDIO_COL = "music_id"
CAPTION_COL = "caption_clean"
CAPTION_EMPTY_COL = "caption_empty"
TAGS_COL = "tags_clean"

# --- Scale ---
MAX_FIT_POINTS = 200_000   # unique texts used to fit UMAP/HDBSCAN (None = use all; slow at 1M)
ASSIGN_ALL = True          # label the remaining videos via UMAP.transform + HDBSCAN.approximate_predict
XY_ASSIGN_ALL = False      # also place videos outside the fit sample on the 2-D map (slow, like ASSIGN_ALL);
                           # False -> their 2-D coordinates are NaN (identical texts still share coordinates)
TRANSFORM_CHUNK = 50_000
SEED = 42

# --- UMAP (clustering pass) ---
N_CLUSTER_DIMS = 50
UMAP_N_NEIGHBORS = 15
UMAP_METRIC = "cosine"
UMAP_RANDOM_STATE = None   # None = multi-threaded/fast; set to SEED for reproducible (single-threaded, slow)

# --- HDBSCAN (per modality) ---
MIN_CLUSTER_SIZE = {"caption": 60, "hashtag": 60}   # main knob: larger -> fewer, broader topics
MIN_SAMPLES = {"caption": 5, "hashtag": 10}         # smaller -> fewer outliers

# --- c-TF-IDF ---
N_KEYWORDS = 10
MIN_DF = 5                 # ignore terms appearing in fewer than this many documents

# --- Plot (2-D UMAP) ---
PLOT_MIN_DIST = 0.1
N_TOPICS_PLOT = 20         # this many largest topics get their own color (max 20 = tab20)
MAX_PLOT_POINTS = 150_000
POINT_SIZE = 1.5
GREY = "#d0d0d0"
FIGSIZE = (15, 9)

# --- Special topic codes in the assignments file ---
TOPIC_OUTLIER = -1         # HDBSCAN noise
TOPIC_NO_TEXT = -2         # no usable text / zero embedding
TOPIC_UNASSIGNED = -3      # only if ASSIGN_ALL = False


# %% Helpers
def ctfidf_keywords(doc_term, labels, vocab, n_words):
    """Class-based TF-IDF (BERTopic formulation). Returns {topic: [keywords]}.

    tf  = term count in topic, L1-normalized per topic
    idf = log(1 + avg_terms_per_topic / total_count_of_term_across_topics)
    """
    topics = np.unique(labels[labels >= 0])
    row = pd.Index(topics).get_indexer(labels)
    mask = row >= 0
    membership = sparse.csr_matrix(
        (np.ones(mask.sum(), dtype=np.float32), (row[mask], np.flatnonzero(mask))),
        shape=(len(topics), len(labels)),
    )
    class_term = membership @ doc_term                       # topics x vocab counts
    tf = normalize(class_term, norm="l1", axis=1)
    term_total = np.asarray(class_term.sum(axis=0)).ravel()
    avg_terms = float(class_term.sum(axis=1).mean())
    idf = np.log(avg_terms / np.maximum(term_total, 1) + 1)
    weights = (tf @ sparse.diags(idf)).tocsr()

    keywords = {}
    for i, t in enumerate(topics):
        w = weights[i].toarray().ravel()
        top = np.argsort(-w)[:n_words]
        keywords[t] = [vocab[j] for j in top if w[j] > 0]
    return keywords


def plot_topics(name, xy, labels, topics_df, rng):
    """2-D UMAP scatter. Largest N_TOPICS_PLOT topics colored; the rest grey."""
    top = pd.Series(labels[labels >= 0]).value_counts().index[:N_TOPICS_PLOT]
    kw = topics_df.set_index("topic")["keywords"].str.split(", ").str[:3].str.join(", ")

    if len(labels) > MAX_PLOT_POINTS:
        sel = rng.choice(len(labels), MAX_PLOT_POINTS, replace=False)
        xy, labels = xy[sel], labels[sel]

    fig, ax = plt.subplots(figsize=FIGSIZE)
    other = ~np.isin(labels, top)
    ax.scatter(xy[other, 0], xy[other, 1], s=POINT_SIZE, c=GREY, alpha=0.3,
               linewidths=0, rasterized=True, label="other topics / outliers")

    cmap = plt.get_cmap("tab20")
    palette = [cmap(i) for i in (*range(0, 20, 2), *range(1, 20, 2))]  # saturated shades first
    for k, t in enumerate(top):
        m = labels == t
        ax.scatter(xy[m, 0], xy[m, 1], s=POINT_SIZE, color=palette[k % 20], alpha=0.6,
                   linewidths=0, rasterized=True, label=f"{t}: {kw.get(t, '')}")
        ax.text(np.median(xy[m, 0]), np.median(xy[m, 1]), str(t), fontsize=9,
                weight="bold", ha="center", va="center",
                bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none", alpha=0.7))

    ax.set_title(f"{name.title()} topics: 2-D UMAP (top {len(top)} topics colored)",
                 fontsize=14, pad=15)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.spines[["top", "right", "left", "bottom"]].set_visible(False)
    ax.legend(loc="center left", bbox_to_anchor=(1.01, 0.5), markerscale=8, fontsize=8,
              frameon=False)
    fig.tight_layout()
    fig.savefig(f"topics_{name}_umap.png", dpi=200, bbox_inches="tight")
    plt.show()


def run_topic_model(name, emb, keys, vectorizer, rng):
    """UMAP(50-d) -> HDBSCAN -> c-TF-IDF -> 2-D UMAP plot.

    emb: (n_videos, dim) embeddings; keys: Series of per-video text (also the c-TF-IDF document).
    Returns (topic per video [int32], topics dataframe, 2-D coordinates per video [n x 2, NaN if none]).
    """
    print(f"\n{'=' * 20} {name.upper()} {'=' * 20}")
    n = len(keys)
    valid = ((np.linalg.norm(emb, axis=1) > 0) & (keys.str.len() > 0)).to_numpy()

    # ---- choose fit sample: valid rows, unique texts, capped at MAX_FIT_POINTS ----
    valid_idx = np.flatnonzero(valid)
    uniq_idx = valid_idx[~keys.iloc[valid_idx].duplicated().to_numpy()]
    if MAX_FIT_POINTS and len(uniq_idx) > MAX_FIT_POINTS:
        fit_idx = np.sort(rng.choice(uniq_idx, MAX_FIT_POINTS, replace=False))
    else:
        fit_idx = uniq_idx
    print(f"{valid.sum():,} of {n:,} videos have usable text; "
          f"{len(uniq_idx):,} unique; fitting on {len(fit_idx):,}")
    X = emb[fit_idx]

    # ---- 1) UMAP to 50 dims ----
    print(f"UMAP -> {N_CLUSTER_DIMS} dims...")
    reducer = umap.UMAP(
        n_components=N_CLUSTER_DIMS, n_neighbors=UMAP_N_NEIGHBORS, min_dist=0.0,
        metric=UMAP_METRIC, random_state=UMAP_RANDOM_STATE, verbose=True,
    )
    X_reduced = reducer.fit_transform(X)

    # ---- 2) HDBSCAN ----
    mcs, ms = MIN_CLUSTER_SIZE[name], MIN_SAMPLES[name]
    print(f"HDBSCAN (min_cluster_size={mcs}, min_samples={ms})...")
    clusterer = hdbscan.HDBSCAN(
        min_cluster_size=mcs, min_samples=ms, metric="euclidean",
        cluster_selection_method="eom", prediction_data=True,
    )
    labels = clusterer.fit_predict(X_reduced)
    n_topics = labels.max() + 1
    print(f"{n_topics} topics; outliers: {(labels == -1).mean():.1%} of fit sample")
    if n_topics == 0:
        raise RuntimeError("HDBSCAN found no clusters. Lower MIN_CLUSTER_SIZE / MIN_SAMPLES.")

    # ---- 3) c-TF-IDF ----
    print("c-TF-IDF...")
    doc_term = vectorizer.fit_transform(keys.iloc[fit_idx])
    vocab = vectorizer.get_feature_names_out()
    keywords = ctfidf_keywords(doc_term, labels, vocab, N_KEYWORDS)

    # ---- assign every video a topic (identical texts share a topic) ----
    key_to_topic = dict(zip(keys.iloc[fit_idx], labels))
    if ASSIGN_ALL:
        rest_idx = np.setdiff1d(uniq_idx, fit_idx)
        if len(rest_idx):
            print(f"Assigning {len(rest_idx):,} remaining unique texts...")
        for chunk in np.array_split(rest_idx, max(1, len(rest_idx) // TRANSFORM_CHUNK)):
            if len(chunk) == 0:
                continue
            pred, _ = hdbscan.approximate_predict(clusterer, reducer.transform(emb[chunk]))
            key_to_topic.update(zip(keys.iloc[chunk], pred))

    topic_all = keys.map(key_to_topic)
    topic_all = topic_all.where(valid, TOPIC_NO_TEXT).fillna(TOPIC_UNASSIGNED).astype("int32")

    # ---- topics table ----
    fit_sizes = pd.Series(labels[labels >= 0]).value_counts()
    video_sizes = topic_all[topic_all >= 0].value_counts()
    topics_df = pd.DataFrame({
        "topic": list(keywords),
        "n_fit_docs": [int(fit_sizes.get(t, 0)) for t in keywords],
        "n_videos": [int(video_sizes.get(t, 0)) for t in keywords],
        "keywords": [", ".join(kw) for kw in keywords.values()],
    }).sort_values("n_videos", ascending=False)
    topics_df.to_csv(f"topics_{name}.csv", index=False)

    print(f"\nTop topics by video count ({name}):")
    print(topics_df.head(15).to_string(index=False, max_colwidth=70))

    # ---- 4) 2-D UMAP on the original embeddings, colored by topic ----
    print("\nUMAP -> 2 dims for plotting...")
    xy_reducer = umap.UMAP(
        n_components=2, n_neighbors=UMAP_N_NEIGHBORS, min_dist=PLOT_MIN_DIST,
        metric=UMAP_METRIC, random_state=UMAP_RANDOM_STATE, verbose=True,
    )
    xy = xy_reducer.fit_transform(X)
    plot_topics(name, xy, labels, topics_df, rng)

    # ---- per-video 2-D coordinates (identical texts share coordinates) ----
    key_to_x = dict(zip(keys.iloc[fit_idx], xy[:, 0]))
    key_to_y = dict(zip(keys.iloc[fit_idx], xy[:, 1]))
    if XY_ASSIGN_ALL:
        rest_idx = np.setdiff1d(uniq_idx, fit_idx)
        if len(rest_idx):
            print(f"Placing {len(rest_idx):,} remaining unique texts on the 2-D map...")
        for chunk in np.array_split(rest_idx, max(1, len(rest_idx) // TRANSFORM_CHUNK)):
            if len(chunk) == 0:
                continue
            pts = xy_reducer.transform(emb[chunk])
            key_to_x.update(zip(keys.iloc[chunk], pts[:, 0]))
            key_to_y.update(zip(keys.iloc[chunk], pts[:, 1]))
    xy_all = np.column_stack([
        keys.map(key_to_x).to_numpy(dtype=np.float32, na_value=np.nan),
        keys.map(key_to_y).to_numpy(dtype=np.float32, na_value=np.nan),
    ])
    xy_all[~valid] = np.nan
    print(f"2-D coordinates available for {np.isfinite(xy_all[:, 0]).mean():.1%} of videos")

    return topic_all.to_numpy(), topics_df, xy_all


# %% Load
df = pd.read_parquet(
    CLEAN_PARQUET, columns=[ID_COL, AUDIO_COL, CAPTION_COL, CAPTION_EMPTY_COL, TAGS_COL]
).reset_index(drop=True)
caption_emb = np.load(CAPTION_EMB_NPY)
hashtag_emb = np.load(HASHTAG_EMB_NPY)
assert len(df) == len(caption_emb) == len(hashtag_emb), "embeddings and parquet rows don't align"
print(f"{len(df):,} videos")

# Per-video text for each modality (also used as the c-TF-IDF document)
caption_keys = df[CAPTION_COL].where(~df[CAPTION_EMPTY_COL], "").str.lower()
hashtag_keys = pd.Series([" ".join(sorted(t)) for t in df[TAGS_COL]], index=df.index)

rng = np.random.default_rng(SEED)


# %% Captions
caption_topic, caption_topics, caption_xy = run_topic_model(
    "caption",
    caption_emb,
    caption_keys,
    CountVectorizer(stop_words="english", min_df=MIN_DF, token_pattern=r"(?u)\b[^\W\d_]{2,}\b"),
    rng,
)
pd.DataFrame({ID_COL: df[ID_COL], "caption_topic": caption_topic}).to_parquet("captions_backup.parquet")

# %% Clear Memory
import gc

# Delete the large caption inputs
del caption_emb
del caption_keys

# Force the garbage collector to release the memory
gc.collect()

# %% Hashtags
# token_pattern keeps each hashtag whole, so c-TF-IDF keywords are real hashtags
hashtag_topic, hashtag_topics, hashtag_xy = run_topic_model(
    "hashtag",
    hashtag_emb,
    hashtag_keys,
    CountVectorizer(min_df=MIN_DF, token_pattern=r"\S+", lowercase=False),
    rng,
)

pd.DataFrame({ID_COL: df[ID_COL], "hashtag_topic": hashtag_topic}).to_parquet("hashtags_backup.parquet")


# %% Save per-video assignments
assignments = pd.DataFrame({
    ID_COL: df[ID_COL],
    AUDIO_COL: df[AUDIO_COL],
    "caption_topic": caption_topic,
    "hashtag_topic": hashtag_topic,
    "caption_umap_x": caption_xy[:, 0],
    "caption_umap_y": caption_xy[:, 1],
    "hashtag_umap_x": hashtag_xy[:, 0],
    "hashtag_umap_y": hashtag_xy[:, 1],
})
assignments.to_parquet(ASSIGNMENTS_PARQUET, index=False)
print(f"\nSaved {ASSIGNMENTS_PARQUET}")
print("Topic codes: -1 = HDBSCAN outlier, -2 = no usable text, -3 = not assigned")