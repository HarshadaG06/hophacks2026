# %% Config
import ast
import json
import re
import unicodedata
from itertools import chain

import numpy as np
import pandas as pd

# --- Files ---
INPUT_PARQUET = "top_500_audios.parquet"      # already filtered to the top 500 audios
CLEAN_PARQUET = "top_500_text_clean.parquet"  # output
HASHTAG_STATS_CSV = "hashtag_stats.csv"       # review this to tune the thresholds

# --- Columns ---
AUDIO_COL = "music_id"
DESC_COL = "desc"                  # caption + hashtags
CHALLENGES_COL = "challenges"      # extracted hashtags (stored as a string)

# --- Caption cleaning ---
# Removed from captions: hashtags, @mentions, URLs
STRIP_RE = re.compile(r"#[^\s#]+|@[\w.]+|https?://\S+|www\.\S+")
TAG_RE = re.compile(r"#(\w+)")                                  # extract hashtag names from desc
TAG_KEYS = ("title", "hashtag_name", "name", "challenge_name")  # keys if challenges holds dicts

# --- Redundant hashtag filtering ---
MAX_AUDIO_SHARE = 0.99   # drop tags used by more than this share of the audios
MIN_TAG_VIDEOS = 5       # drop tags used in fewer videos than this (set to 1 to disable)
BLOCKLIST = {
    "fyp", "fy", "foryou", "foryoupage", "fypage", "fypシ", "xyzbca", "xyzcba",
    "viral", "goviral", "trending", "trend", "tiktok", "capcut", "capcutedit",
    "explore", "explorepage", "parati", "pourtoi",
}
BLOCKLIST_PATTERNS = [r"^fy+p", r"^foryou", r"^xyz[a-z]{2,4}$", r"^viral"]
BLOCK_RE = re.compile("|".join(BLOCKLIST_PATTERNS))


# %% Helpers
def challenge_tags(value):
    """Raw tag strings from a `challenges` cell.

    Handles JSON or Python-repr lists (of str or dict), and plain delimited strings
    such as "fyp,dance" or "#fyp #dance".
    """
    if isinstance(value, str):
        s = value.strip()
        if s in ("", "[]", "{}", "nan", "None", "null"):
            return []
        if s[0] in "[{":
            parsed = None
            for parser in (json.loads, ast.literal_eval):
                try:
                    parsed = parser(s)
                    break
                except (ValueError, SyntaxError):
                    continue
            if parsed is None:  # unparseable: pull out quoted tokens
                return re.findall(r"""['"]([^'"]+)['"]""", s)
            value = parsed
        else:
            return [t for t in re.split(r"[,;|\s]+", s) if t]
    if isinstance(value, dict):
        value = [value]
    if not isinstance(value, (list, tuple, np.ndarray)):
        return []  # None / NaN / unexpected type
    tags = []
    for item in value:
        if isinstance(item, dict):
            item = next((item[k] for k in TAG_KEYS if item.get(k)), None)
        if item:
            tags.append(str(item))
    return tags


def build_tags(challenges, desc_tags):
    """Union of challenge tags and hashtags found in desc; normalized, de-duplicated, order kept."""
    tags = []
    for t in chain(challenge_tags(challenges), desc_tags):
        t = unicodedata.normalize("NFKC", str(t)).lstrip("#").strip().lower()
        if t:
            tags.append(t)
    return list(dict.fromkeys(tags))


def is_blocked(tag):
    return tag in BLOCKLIST or bool(BLOCK_RE.search(tag))


# %% Load
df = pd.read_parquet(INPUT_PARQUET)
df[DESC_COL] = df[DESC_COL].fillna("")
print(f"{len(df):,} videos across {df[AUDIO_COL].nunique()} audios")

# Sanity check: eyeball what `challenges` actually looks like
print("\nSample `challenges` values:")
print(df[CHALLENGES_COL].dropna().head(5).to_list())


# %% Step 2: clean captions (strip hashtags, mentions, URLs)
print("\nCleaning captions...")
df["caption_clean"] = (
    df[DESC_COL]
    .str.replace(STRIP_RE, " ", regex=True)
    .str.replace(r"\s+", " ", regex=True)
    .str.strip()
)
# Captions with no letters/digits left (empty, or emoji/punctuation only)
df["caption_empty"] = ~df["caption_clean"].str.contains(r"\w", regex=True)


# %% Step 3a: build per-video tag lists (challenges + hashtags in desc)
print("Building hashtag lists...")
desc_tags = df[DESC_COL].str.findall(TAG_RE)
df["tags_raw"] = [build_tags(c, d) for c, d in zip(df[CHALLENGES_COL], desc_tags)]


# %% Step 3b: audio-level document frequency of each hashtag
print("Computing hashtag statistics...")
n_audios_total = df[AUDIO_COL].nunique()

exploded = (
    df[[AUDIO_COL, "tags_raw"]]
    .explode("tags_raw")
    .dropna(subset=["tags_raw"])
    .rename(columns={"tags_raw": "tag"})
)
stats = exploded.groupby("tag").agg(
    n_videos=(AUDIO_COL, "size"),
    n_audios=(AUDIO_COL, "nunique"),
)
stats["audio_share"] = stats["n_audios"] / n_audios_total

blocked = stats.index.map(is_blocked).to_numpy(dtype=bool)
too_common = (stats["audio_share"] > MAX_AUDIO_SHARE).to_numpy()
too_rare = (stats["n_videos"] < MIN_TAG_VIDEOS).to_numpy()
stats["reason"] = np.select(
    [blocked, too_common, too_rare], ["blocklist", "too_common", "too_rare"], default="kept"
)
stats = stats.sort_values(["n_audios", "n_videos"], ascending=False)
stats.to_csv(HASHTAG_STATS_CSV)

drop_tags = set(stats.index[stats["reason"] != "kept"])

# print(df.columns.tolist())

# %% Step 3c: apply filter
df["tags_clean"] = [[t for t in tags if t not in drop_tags] for tags in df["tags_raw"]]
df["tags_text"] = df["tags_clean"].str.join(" ")  # convenient string form for embedding / TF-IDF
df["has_text"] = ~df["caption_empty"] | (df["tags_clean"].str.len() > 0)


# %% Save + summary
out = df.drop(columns=[CHALLENGES_COL, "tags_raw"])
out.to_parquet(CLEAN_PARQUET, index=False)
print(f"\nSaved {CLEAN_PARQUET} and {HASHTAG_STATS_CSV}")

print("\n--- Summary ---")
print(f"Empty captions after cleaning: {df['caption_empty'].mean():.1%}")
print(f"Videos with no tags left:      {(df['tags_clean'].str.len() == 0).mean():.1%}")
print(f"Videos with no usable text:    {(~df['has_text']).mean():.1%}")
print(f"Unique tags: {len(stats):,} -> kept {(stats['reason'] == 'kept').sum():,}")
print(stats["reason"].value_counts().to_string())

print("\nMost widespread dropped tags:")
print(stats[stats["reason"] != "kept"].head(25)[["n_videos", "n_audios", "audio_share", "reason"]])

print("\nMost widespread kept tags:")
print(stats[stats["reason"] == "kept"].head(25)[["n_videos", "n_audios", "audio_share"]])