# %% Config
# Sweep HDBSCAN settings on a subsample BEFORE running the full topic model.
# UMAP (the slow part) is fit once per modality; HDBSCAN is then swept over that fixed space.
# pip install umap-learn hdbscan scikit-learn scipy matplotlib joblib
from itertools import chain

import hdbscan
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import umap
from joblib import Memory
from scipy import sparse
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import adjusted_rand_score
from sklearn.preprocessing import normalize

# --- Files / columns (same as the topic model script) ---
CLEAN_PARQUET = "top_500_text_clean.parquet"
CAPTION_EMB_NPY = "caption_embeddings.npy"
HASHTAG_EMB_NPY = "hashtag_embeddings.npy"
CAPTION_COL = "caption_clean"
CAPTION_EMPTY_COL = "caption_empty"
TAGS_COL = "tags_clean"
HDBSCAN_CACHE_DIR = "hdbscan_cache"     # joblib cache; safe to delete

# --- Sweep grid ---
SWEEP_POINTS = 30_000                   # unique texts used for the sweep
FULL_FIT_POINTS = 200_000               # MAX_FIT_POINTS of the main script (only used to rescale)
MIN_CLUSTER_SIZES = [8, 15, 30, 60, 120]   # sized for SWEEP_POINTS; rescaled in the output
MIN_SAMPLES_LIST = [1, 5, 10, 20]          # combos with min_samples > min_cluster_size are skipped
SEED = 42

# --- UMAP (match the main script) ---
N_CLUSTER_DIMS = 50
UMAP_N_NEIGHBORS = 15
UMAP_METRIC = "cosine"

# --- Metrics ---
N_KEYWORDS = 10
MIN_DF = 5
N_STABILITY_REPEATS = 2                 # 0 disables stability (the slowest metric)
STABILITY_FRACTION = 0.8

# --- Shortlist filters (a starting point, not a verdict) ---
MAX_OUTLIER_FRAC = 0.5
MAX_LARGEST_SHARE = 0.3                 # no single "catch-all" topic bigger than this share
MIN_TOPICS = 5


# %% Helpers
def pick_sample(emb, keys, n, rng):
    """Valid (non-zero vector, non-empty text), de-duplicated rows, randomly capped at n.

    Returns (sample indices, total number of unique valid texts).
    """
    valid = ((np.linalg.norm(emb, axis=1) > 0) & (keys.str.len() > 0)).to_numpy()
    valid_idx = np.flatnonzero(valid)
    uniq_idx = valid_idx[~keys.iloc[valid_idx].duplicated().to_numpy()]
    if len(uniq_idx) > n:
        return np.sort(rng.choice(uniq_idx, n, replace=False)), len(uniq_idx)
    return uniq_idx, len(uniq_idx)


def get_umap(name, idx, X):
    """50-d UMAP of the sample, cached to disk so the grid can be changed without refitting."""
    cache = f"sweep_umap_{name}.npz"
    try:
        saved = np.load(cache)
        if np.array_equal(saved["idx"], idx):
            print(f"Reusing cached UMAP from {cache}")
            return saved["X"]
    except FileNotFoundError:
        pass
    print(f"UMAP -> {N_CLUSTER_DIMS} dims on {len(idx):,} points...")
    X_red = umap.UMAP(
        n_components=N_CLUSTER_DIMS, n_neighbors=UMAP_N_NEIGHBORS, min_dist=0.0,
        metric=UMAP_METRIC, verbose=True,
    ).fit_transform(X)
    np.savez(cache, idx=idx, X=X_red)
    return X_red


def cluster(X, min_cluster_size, min_samples, memory, want_validity=False):
    # `memory` caches the expensive tree; min_cluster_size only affects the cheap extraction step,
    # so sweeping it at a fixed min_samples is nearly free.
    c = hdbscan.HDBSCAN(
        min_cluster_size=min_cluster_size, min_samples=min_samples, metric="euclidean",
        cluster_selection_method="eom", gen_min_span_tree=want_validity, memory=memory,
    )
    labels = c.fit_predict(X)
    return labels, (c.relative_validity_ if want_validity else np.nan)


def ctfidf_top_terms(doc_term, labels, n_words):
    """c-TF-IDF (BERTopic formulation). Returns a list of arrays of top term indices per topic."""
    topics = np.unique(labels[labels >= 0])
    row = pd.Index(topics).get_indexer(labels)
    mask = row >= 0
    membership = sparse.csr_matrix(
        (np.ones(mask.sum(), dtype=np.float32), (row[mask], np.flatnonzero(mask))),
        shape=(len(topics), len(labels)),
    )
    class_term = membership @ doc_term
    tf = normalize(class_term, norm="l1", axis=1)
    term_total = np.asarray(class_term.sum(axis=0)).ravel()
    idf = np.log(float(class_term.sum(axis=1).mean()) / np.maximum(term_total, 1) + 1)
    weights = (tf @ sparse.diags(idf)).tocsr()
    out = []
    for i in range(len(topics)):
        w = weights[i].toarray().ravel()
        top = np.argsort(-w)[:n_words]
        out.append(top[w[top] > 0])
    return out


def npmi_coherence(binary_csc, top_terms, n_docs):
    """Mean NPMI over keyword pairs within each topic (document co-occurrence), averaged over topics."""
    scores = []
    for idx in top_terms:
        if len(idx) < 2:
            continue
        sub = binary_csc[:, idx]
        co = (sub.T @ sub).toarray()
        df = np.diag(co)
        i, j = np.triu_indices(len(idx), 1)
        p_ij, p_i, p_j = co[i, j] / n_docs, df[i] / n_docs, df[j] / n_docs
        with np.errstate(divide="ignore", invalid="ignore"):
            npmi = np.log(p_ij / (p_i * p_j)) / -np.log(p_ij)
        npmi = np.where(p_ij >= 1, 1.0, np.where(p_ij > 0, npmi, -1.0))
        scores.append(npmi.mean())
    return float(np.mean(scores)) if scores else np.nan


def topic_metrics(labels, doc_term, binary_csc):
    nan = np.nan
    out = {"n_topics": int(labels.max() + 1), "outlier_frac": float((labels == -1).mean()),
           "largest_share": nan, "coherence_npmi": nan, "diversity": nan}
    if out["n_topics"] == 0:
        return out
    sizes = np.bincount(labels[labels >= 0])
    out["largest_share"] = float(sizes.max() / sizes.sum())
    terms = ctfidf_top_terms(doc_term, labels, N_KEYWORDS)
    n_terms = sum(len(t) for t in terms)
    out["diversity"] = len(set(chain.from_iterable(terms))) / n_terms if n_terms else nan
    out["coherence_npmi"] = npmi_coherence(binary_csc, terms, doc_term.shape[0])
    return out


def stability(X, labels_full, subsets, mcs, ms, memory):
    """Mean ARI between the full clustering and clusterings of random subsets (non-noise points)."""
    aris = []
    for sub in subsets:
        lab_sub, _ = cluster(X[sub], mcs, ms, memory)
        a, b = labels_full[sub], lab_sub
        keep = (a >= 0) & (b >= 0)
        if keep.sum() > 1 and len(np.unique(a[keep])) > 1 and len(np.unique(b[keep])) > 1:
            aris.append(adjusted_rand_score(a[keep], b[keep]))
    return float(np.mean(aris)) if aris else np.nan


def plot_grid(name, res):
    panels = [
        ("n_topics", "Number of topics"),
        ("outlier_frac", "Outlier share (lower = better)"),
        ("largest_share", "Largest topic share (lower = better)"),
        ("coherence_npmi", "Keyword coherence, NPMI (higher = better)"),
        ("diversity", "Keyword diversity (higher = better)"),
        ("relative_validity", "HDBSCAN relative validity (higher = better)"),
        ("stability_ari", "Stability, ARI (higher = better)"),
    ]
    fig, axes = plt.subplots(2, 4, figsize=(19, 8))
    for ax, (col, title) in zip(axes.ravel(), panels):
        grid = res.pivot(index="min_samples", columns="min_cluster_size", values=col)
        im = ax.imshow(np.ma.masked_invalid(grid.values), cmap="viridis", aspect="auto")
        ax.set_xticks(range(grid.shape[1]), grid.columns)
        ax.set_yticks(range(grid.shape[0]), grid.index)
        ax.set_xlabel("min_cluster_size (sweep scale)")
        ax.set_ylabel("min_samples")
        ax.set_title(title, fontsize=10)
        for (r, c), v in np.ndenumerate(grid.values):
            if not np.isnan(v):
                ax.text(c, r, f"{v:.0f}" if col == "n_topics" else f"{v:.2f}",
                        ha="center", va="center", fontsize=8,
                        color="black" if im.norm(v) > 0.6 else "white")
    for ax in axes.ravel()[len(panels):]:
        ax.axis("off")
    fig.suptitle(f"HDBSCAN sweep: {name}", fontsize=14)
    fig.tight_layout()
    fig.savefig(f"tuning_{name}.png", dpi=150, bbox_inches="tight")
    plt.show()


def tune(name, emb, keys, vectorizer):
    print(f"\n{'=' * 20} {name.upper()} {'=' * 20}")
    rng = np.random.default_rng(SEED)
    idx, n_unique = pick_sample(emb, keys, SWEEP_POINTS, rng)
    n = len(idx)
    print(f"Sweep sample: {n:,} of {n_unique:,} unique texts")
    # the main script fits on min(unique texts, FULL_FIT_POINTS) points
    scale = min(n_unique, FULL_FIT_POINTS) / n

    X = get_umap(name, idx, emb[idx])

    doc_term = vectorizer.fit_transform(keys.iloc[idx])
    binary = (doc_term > 0).astype(np.float32).tocsc()

    memory = Memory(HDBSCAN_CACHE_DIR, verbose=0)
    subsets = [np.sort(rng.choice(n, int(STABILITY_FRACTION * n), replace=False))
               for _ in range(N_STABILITY_REPEATS)]

    rows = []
    for ms in MIN_SAMPLES_LIST:
        for mcs in MIN_CLUSTER_SIZES:
            if ms > mcs:
                continue
            labels, rv = cluster(X, mcs, ms, memory, want_validity=True)
            row = {"min_cluster_size": mcs, "min_samples": ms,
                   "min_cluster_size_at_full_scale": int(round(mcs * scale)),
                   **topic_metrics(labels, doc_term, binary), "relative_validity": rv,
                   "stability_ari": np.nan}
            if N_STABILITY_REPEATS and row["n_topics"] > 1:
                row["stability_ari"] = stability(X, labels, subsets, mcs, ms, memory)
            rows.append(row)
            print(f"  mcs={mcs:>4} ms={ms:>3} -> {row['n_topics']:>4} topics, "
                  f"{row['outlier_frac']:.0%} outliers, npmi={row['coherence_npmi']:.3f}")

    res = pd.DataFrame(rows)
    res.to_csv(f"tuning_{name}.csv", index=False)
    plot_grid(name, res)

    short = res[
        (res["outlier_frac"] <= MAX_OUTLIER_FRAC)
        & (res["largest_share"] <= MAX_LARGEST_SHARE)
        & (res["n_topics"] >= MIN_TOPICS)
    ].sort_values("coherence_npmi", ascending=False)
    print(f"\nShortlist for {name} (filters: outliers <= {MAX_OUTLIER_FRAC:.0%}, "
          f"largest topic <= {MAX_LARGEST_SHARE:.0%}, >= {MIN_TOPICS} topics; sorted by coherence):")
    cols = ["min_cluster_size", "min_cluster_size_at_full_scale", "min_samples", "n_topics",
            "outlier_frac", "largest_share", "coherence_npmi", "diversity",
            "relative_validity", "stability_ari"]
    print(short[cols].round(3).to_string(index=False) if len(short)
          else "  (nothing passed the filters -- loosen them or widen the grid)")
    return res


# %% Load
df = pd.read_parquet(CLEAN_PARQUET, columns=[CAPTION_COL, CAPTION_EMPTY_COL, TAGS_COL])
caption_emb = np.load(CAPTION_EMB_NPY)
hashtag_emb = np.load(HASHTAG_EMB_NPY)
assert len(df) == len(caption_emb) == len(hashtag_emb), "embeddings and parquet rows don't align"

caption_keys = df[CAPTION_COL].where(~df[CAPTION_EMPTY_COL], "").str.lower()
hashtag_keys = pd.Series([" ".join(sorted(t)) for t in df[TAGS_COL]], index=df.index)


# %% Captions
caption_res = tune(
    "caption", caption_emb, caption_keys,
    CountVectorizer(stop_words="english", min_df=MIN_DF, token_pattern=r"(?u)\b[^\W\d_]{2,}\b"),
)


# %% Hashtags
hashtag_res = tune(
    "hashtag", hashtag_emb, hashtag_keys,
    CountVectorizer(min_df=MIN_DF, token_pattern=r"\S+", lowercase=False),
)