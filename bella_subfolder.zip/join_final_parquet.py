# %% Config
import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from pathlib import Path

# --- Inputs ---
TOP500_PARQUET = "top_500_audios.parquet"           # original video metadata
ASSIGNMENTS_PARQUET = "topic_assignments.parquet"   # from topic_model_umap_hdbscan.py
CAPTION_TOPICS_CSV = "topics_caption.csv"           # topic id -> c-TF-IDF keywords
HASHTAG_TOPICS_CSV = "topics_hashtag.csv"

# --- Output ---
OUTPUT_PARQUET = "final.parquet"

# --- Column names ---
ID_COL = "id"
AUDIO_COL = "music_id"
TIME_COL = "create_time"
VIEWS_SRC_COL = "play_count"     # renamed to view_count in the output
URL_COL = "url"

# Columns the join needs from each file (checked in the inspection cell)
EXPECTED = {
    TOP500_PARQUET: [ID_COL, AUDIO_COL, TIME_COL, VIEWS_SRC_COL, URL_COL],
    ASSIGNMENTS_PARQUET: [
        ID_COL, AUDIO_COL, "caption_topic", "hashtag_topic",
        "caption_umap_x", "caption_umap_y", "hashtag_umap_x", "hashtag_umap_y",
    ],
    CAPTION_TOPICS_CSV: ["topic", "keywords"],
    HASHTAG_TOPICS_CSV: ["topic", "keywords"],
}

# Source column -> output column
RENAME = {
    VIEWS_SRC_COL: "view_count",
    "hashtag_umap_x": "hash_umap_x",
    "hashtag_umap_y": "hash_umap_y",
    "hashtag_topic": "hash_topic_id",
    "caption_topic": "caption_topic_id",
}
FINAL_COLUMNS = [
    "id", "music_id", "create_time", "view_count", "url",
    "hash_umap_x", "hash_umap_y", "caption_umap_x", "caption_umap_y",
    "hash_topic_id", "hash_topic_keywords",
    "caption_topic_id", "caption_topic_keywords",
]


# %% Inspect schemas and column names (run this before the join)
def inspect_file(path, expected):
    """Print schema, row count, and a 3-row preview. Returns a list of problems found."""
    print("=" * 90)
    print(path)
    p = Path(path)
    if not p.exists():
        print("  !! FILE NOT FOUND")
        return [f"{path}: file not found"]

    if p.suffix == ".parquet":
        pf = pq.ParquetFile(p)
        schema = pf.schema_arrow
        cols = schema.names
        print(f"  rows: {pf.metadata.num_rows:,}   columns: {len(cols)}   "
              f"row groups: {pf.metadata.num_row_groups}")
        for field in schema:
            print(f"    {field.name:<22} {field.type}")
        preview = next(pf.iter_batches(batch_size=3)).to_pandas()
    else:
        full = pd.read_csv(p)
        cols = list(full.columns)
        print(f"  rows: {len(full):,}   columns: {len(cols)}")
        for c, t in full.dtypes.items():
            print(f"    {c:<22} {t}")
        preview = full.head(3)

    print("\n  preview:")
    print(preview.to_string(max_colwidth=40, index=False))

    problems = []
    missing = [c for c in expected if c not in cols]
    if missing:
        print(f"\n  !! MISSING expected columns: {missing}")
        problems.append(f"{path}: missing {missing}")
    else:
        print("\n  all expected columns present")

    if p.suffix == ".parquet" and ID_COL in cols:
        ids = pd.read_parquet(p, columns=[ID_COL])[ID_COL]
        n_dup = int(ids.duplicated().sum())
        print(f"  duplicate {ID_COL} values: {n_dup:,}")
    return problems


PROBLEMS = []
for path, expected_cols in EXPECTED.items():
    PROBLEMS += inspect_file(path, expected_cols)

print("\n" + "=" * 90)
if PROBLEMS:
    print("PROBLEMS FOUND -- the join cell will refuse to run until these are fixed:")
    for msg in PROBLEMS:
        print("  -", msg)
    if any("umap" in m for m in PROBLEMS):
        print("\nHint: 2-D UMAP coordinates are only saved by the updated "
              "topic_model_umap_hdbscan.py; earlier runs did not write them.")
else:
    print("All files and expected columns found. Safe to run the join.")


# %% Join
if PROBLEMS:
    raise RuntimeError("Fix the problems reported in the inspection cell first.")

base = pd.read_parquet(
    TOP500_PARQUET, columns=[ID_COL, AUDIO_COL, TIME_COL, VIEWS_SRC_COL, URL_COL]
)
assign = pd.read_parquet(ASSIGNMENTS_PARQUET)

# The assignments file was written in the same row order as the source data. If ids line up
# position by position, attach columns directly (safe even if ids repeat). Otherwise fall back
# to a keyed merge on id, which requires ids to be unique.
aligned = len(base) == len(assign) and bool((base[ID_COL].to_numpy() == assign[ID_COL].to_numpy()).all())

assign_cols = assign.drop(columns=[ID_COL, AUDIO_COL])
if aligned:
    print("ids align row-by-row -> attaching columns by position")
    if not np.array_equal(base[AUDIO_COL].to_numpy(), assign[AUDIO_COL].to_numpy(), equal_nan=True):
        raise ValueError(f"{AUDIO_COL} differs between the two files even though ids align.")
    df = pd.concat([base.reset_index(drop=True), assign_cols.reset_index(drop=True)], axis=1)
else:
    print("ids do NOT align row-by-row -> merging on id")
    if base[ID_COL].duplicated().any() or assign[ID_COL].duplicated().any():
        raise ValueError(f"Cannot merge on {ID_COL}: duplicates present and row order differs.")
    df = base.merge(assign.drop(columns=[AUDIO_COL]), on=ID_COL, how="left", validate="one_to_one")
    print(f"  videos with no assignment row: {df['caption_topic'].isna().sum():,}")

df = df.rename(columns=RENAME)


def add_keywords(frame, topic_col, csv_path, out_col):
    """Attach each topic's c-TF-IDF keyword string. Codes -1/-2/-3 (no topic) get NaN."""
    kw = pd.read_csv(csv_path, usecols=["topic", "keywords"])
    kw = kw.rename(columns={"topic": topic_col, "keywords": out_col})
    merged = frame.merge(kw, on=topic_col, how="left", validate="many_to_one")
    assert len(merged) == len(frame), "keyword merge changed the row count"
    return merged


df = add_keywords(df, "caption_topic_id", CAPTION_TOPICS_CSV, "caption_topic_keywords")
df = add_keywords(df, "hash_topic_id", HASHTAG_TOPICS_CSV, "hash_topic_keywords")

df = df[FINAL_COLUMNS]
assert len(df) == len(base), "row count changed during the join"


# %% Sanity checks + save
print(f"\n{len(df):,} rows x {df.shape[1]} columns")
print(df.dtypes.to_string())

print("\nNon-null share per column:")
print(df.notna().mean().round(3).to_string())

for prefix in ("caption", "hash"):
    codes = df[f"{prefix}_topic_id"]
    print(f"\n{prefix}: {(codes >= 0).mean():.1%} in a topic | "
          f"{(codes == -1).mean():.1%} outlier | {(codes == -2).mean():.1%} no usable text | "
          f"{(codes == -3).mean():.1%} unassigned")

df.to_parquet(OUTPUT_PARQUET, index=False)
print(f"\nSaved {OUTPUT_PARQUET}")
df.head()